#include "VPN.h"


// Crypto packet header: cipherIVHMACBuf[]
//   ----------------------------------------
//  | ENCRYPTED DATA  |  IV      |  HMAC     |
//   ----------------------------------------
//    CIPHER_BUFF_MAX    IV_SIZE    HASH_SIZE
//   ----------------------------------------
void tunnel (char *ip, int port, char *symKey, char *localSubnet,
             char *remoteSubnet, int readPipe)
{
	struct sockaddr_in sin, sout, from;
	struct ifreq ifr;
	int fd, s, fromlen, soutlen, l, k;
	int outlen, tmplen, mdlen;
	char command[256];
	fd_set fdset;
	int TUNMODE = IFF_TUN;
	unsigned char iv[IV_SIZE],
	         plainBuf[PLAIN_BUFF_MAX],
	         cipherIVHMACBuf[CIPHER_IV_HMAC_MAX],
	         HMACBuf[HASH_SIZE];

	//Network interface
	if ( (fd = open("/dev/net/tun", O_RDWR)) < 0) PERROR("open");
	memset(&ifr, 0, sizeof(ifr));
	ifr.ifr_flags = TUNMODE;
	strncpy(ifr.ifr_name, "toto0", IFNAMSIZ);
	if (ioctl(fd, TUNSETIFF, (void *)&ifr) < 0) PERROR("ioctl");
	printf("Allocated interface %s.\n", ifr.ifr_name);

	//Enable IP forwarding
	system("sysctl net.ipv4.ip_forward=1");

	//ifconfig [device] up
	strcpy(command, "ifconfig "); strcat(command, ifr.ifr_name );
	strcat(command, " up");

	printf("\n\nCommand: %s\n\n", command);

	system(command);
	bzero(command, sizeof(command));

	//ip route add 10.0.[remoteSubnet].0/24 dev [device] src 10.0.[localSubnet].1
	strcpy(command, "ip route add 10.0."); strcat(command, remoteSubnet);
	strcat(command, ".0/24 dev "); strcat(command, ifr.ifr_name );
	strcat(command, " src 10.0."); strcat(command, localSubnet);
	strcat(command, ".1");

	printf("\n\nCommand: %s\n\n", command);

	system(command);
	bzero(command, sizeof(command));
	printf("Interface configured.\n");//--debug

	//UDP socket configuration
	s = socket(PF_INET, SOCK_DGRAM, 0);
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = htonl(INADDR_ANY);
	sin.sin_port = htons(port);
	if ( bind(s, (struct sockaddr *)&sin, sizeof(sin)) < 0) PERROR("bind");

	fromlen = sizeof(from); // Receive IP and port from TCP process
	soutlen = sizeof(sout);
	memset(&sout, 0, sizeof(sout));
	from.sin_family = AF_INET;
	from.sin_port = htons(port); //client and server use same port?
	inet_aton(ip, &from.sin_addr);

	printf("(UDP) Connection with %s:%i established\n",
	       inet_ntoa(from.sin_addr), ntohs(from.sin_port));

	EVP_CIPHER_CTX ctx;
	EVP_CIPHER_CTX_init(&ctx);
	HMAC_CTX mdctx;
	HMAC_CTX_init(&mdctx);

	//Seed IV with randomness and generate initial value
	memset(iv, 0, IV_SIZE);
	if (!RAND_load_file("/dev/urandom", IV_SIZE)) {
		EXIT_CLEAN_CTX("Error: Failed to seed OpenSSL RNG.\n");
	}

	if (!RAND_bytes(iv, IV_SIZE)) {
		EXIT_CLEAN_CTX("Error: Failed to create OpenSSSL random IV.\n");
	}

	int max = s; //find max FD for select()
	if (fd > s)	max = fd;
	else max = s;
	if (max < readPipe)	max = readPipe;
	int cmdRetCode = 0;

	while (1)
	{
		FD_ZERO(&fdset);
		FD_SET(fd, &fdset);
		FD_SET(s, &fdset);
		FD_SET(readPipe, &fdset);

		if (select(max + 1, &fdset, NULL, NULL, NULL) < 0) {
			EXIT_CLEAN_CTX("Error: select()");
		}

		if (FD_ISSET(readPipe, &fdset)) //Process user commands
		{
			if (processCMD(readPipe, symKey) == 1)
			{
				EXIT_CLEAN_CTX("Connection aborted.\n");
			}


		} else if (FD_ISSET(fd, &fdset)) //Send tunnel data
		{
			l = read(fd, plainBuf, PLAIN_BUFF_MAX);
			if (l < 0)	{
				EXIT_CLEAN_CTX("Network interface read error.\n");
			}

			//Generate random IV for each packet sent
			if (!RAND_bytes(iv, IV_SIZE)) {
				EXIT_CLEAN_CTX("Failed to create OpenSSSL random IV.\n");
			}

			EVP_EncryptInit_ex(&ctx, EVP_aes_128_cbc(), NULL, symKey, iv);

			if (!EVP_EncryptUpdate(&ctx, cipherIVHMACBuf, &outlen, plainBuf, l))
			{
				EXIT_CLEAN_CTX("\nError in EncryptUpdate()\n");
			}

			if (!EVP_EncryptFinal_ex(&ctx, cipherIVHMACBuf + outlen, &tmplen))
			{
				printf("\nError in EncryptFinal()\n");
			} else {
				outlen += tmplen;
			}

			//Copy IV to packet
			memcpy(cipherIVHMACBuf + outlen, iv, IV_SIZE);
			HMAC_Init_ex(&mdctx, symKey, KEY_SIZE, EVP_sha256(), NULL);
			HMAC_Update(&mdctx, cipherIVHMACBuf, outlen + IV_SIZE);
			HMAC_Final(&mdctx, cipherIVHMACBuf + outlen + IV_SIZE, &mdlen);

			if (sendto(s, cipherIVHMACBuf, outlen + IV_SIZE + mdlen, 0,
			           (struct sockaddr *)&from, fromlen) < 0) {
				EXIT_CLEAN_CTX("Error: UDP sendto.\n");
			}

		} else if (FD_ISSET(s, &fdset)) {
			l = 0;
			l = recvfrom(s, cipherIVHMACBuf, CIPHER_IV_HMAC_MAX, 0,
			             (struct sockaddr *)&sout, &soutlen);

			if ((sout.sin_addr.s_addr != from.sin_addr.s_addr) || (sout.sin_port != from.sin_port))
				printf("Warnign: Got packet from  %s:%i instead of %s:%i\n",
				       inet_ntoa(sout.sin_addr), ntohs(sout.sin_port),
				       inet_ntoa(from.sin_addr), ntohs(from.sin_port));

			if (l < HASH_SIZE) {
				EXIT_CLEAN_CTX("Error: Missing HMAC Hash.\n");
			}

			//Verify packet
			HMAC_CTX_init(&mdctx);
			HMAC_Init_ex(&mdctx, symKey, KEY_SIZE, EVP_sha256(), NULL);
			HMAC_Update(&mdctx, cipherIVHMACBuf, l - HASH_SIZE);
			HMAC_Final(&mdctx, HMACBuf, &mdlen);
			HMAC_CTX_cleanup(&mdctx);

			//Check hash byte by byte.
			int j;
			for ( j = 0; j < HASH_SIZE; j++)
			{
				if (cipherIVHMACBuf[l - HASH_SIZE + j] != HMACBuf[j])
					printf("Invalid HMAC.\n");
			}

			//decrypt
			EVP_DecryptInit_ex(&ctx, EVP_aes_128_cbc(), NULL,
			                   symKey, cipherIVHMACBuf + l - HASH_SIZE - IV_SIZE); //iv field

			//Decrypt only cipher buffer from packet
			if (!EVP_DecryptUpdate(&ctx, plainBuf, &outlen,
			                       cipherIVHMACBuf, l - HASH_SIZE - IV_SIZE))
			{
				EXIT_CLEAN_CTX("\nError in DecryptUpdate()\n");
			}

			if (!EVP_DecryptFinal_ex(&ctx, plainBuf + outlen, &tmplen))
			{
				printf("\nError in DecryptFinal()\n"); //return 0;
			} else {
				outlen += tmplen;
			}

			if (write(fd, plainBuf, outlen) < 0)
			{
				EXIT_CLEAN_CTX("Network Interface write error.\n");
			}
		}
	}

	EVP_CIPHER_CTX_cleanup(&ctx);
	HMAC_CTX_cleanup(&mdctx);
	return;
}
