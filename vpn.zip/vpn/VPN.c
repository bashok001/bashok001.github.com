#include "VPN.h"

void usage()
{
	fprintf(stderr, "Usage: VPN [-s localPort|-c commonName:serverIP:serverPort] [-n localSubnet]\n");
	printf("\t-s: Creates a VPN server on localPort.\n");
	printf("\t-c: Connects to a remote VPN.\n");
	printf("\t-n: Sets the routable local subnet (server and client must specify). localSubnet must be 0-255* where 10.0.*.0/24\n");
	printf("Terminal commands:\n");
	printf("abort: Aborts connection.\n");
	printf("setrandomkey: Update symmetric key with random value.\n");
	printf("message: Send message to VPN gateway.\n");
	exit(0);
}


int main(int argc, char *argv[])
{
	int port,
	    mode; //error=0, server=1, client=2
	char c, *p, *p2, *ip,
	     *commonName, *localSubnet;
	char *userName,
	     *password;

	if (argc < 2)
		usage();


	while ((c = getopt(argc, argv, "a:n:s:c:ehd")) != -1)
	{
		switch (c)
		{
		case 'n':
			localSubnet = optarg; //--valid format [0-255]
			printf("Local subnet: 10.0.%s.0/24\n", localSubnet);
			printf("Local Gateway: 10.0.%s.1\n", localSubnet);
			break;

		case 'h':
			usage();
			break;

		case 's':
			port = atoi(optarg);
			mode = 1;
			break;

		case 'c':
			p2 = memchr(optarg, ':', 256); //max size of name
			if (!p2) ERROR("Invalid argument : [%s]\n", optarg);
			*p2 = 0;
			commonName = optarg;

			p = memchr(p2, ':', 16); //max ip size in ascii
			if (!p) ERROR("Invalid argument : [%s]\n", p2);
			*p = 0;
			ip = p2 + 1;
			port = atoi(p + 1); //get last 16 bytes only (IP:Prt)
			mode = 2;
			break;

		default:
			usage();
		}
	}

	if (mode == 1)
	{
		serverListener(port, localSubnet);
	} else if (mode == 2) {
		clientConnection(port, ip, commonName, localSubnet);
	}

	return 0;
}