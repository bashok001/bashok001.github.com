#include "VPN.h"

void serverListener(int port, char* localSubnet)
{
    int sockfd, newsockfd, clilen;

    char buffer[256];
    struct sockaddr_in serv_addr, cli_addr;
    int  n, pid;

    /* First call to socket() function */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        perror("ERROR opening socket");
        exit(1);
    }
    /* Initialize socket structure */
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);

    /* Now bind the host address using bind() call.*/
    if (bind(sockfd, (struct sockaddr *) &serv_addr,
             sizeof(serv_addr)) < 0)
    {
        perror("ERROR on binding");
        exit(1);
    }

    printf("Server listening on port %d.\n", port);
    // Listenin for the clients, process will go in sleep mode until incoming connection
    listen(sockfd, 5);
    clilen = sizeof(cli_addr);

    while (1)
    {
        newsockfd = accept(sockfd,
                           (struct sockaddr *) &cli_addr, &clilen);
        if (newsockfd < 0)
        {
            perror("ERROR on accept");
            exit(1);
        }
        //Create child process
        pid = fork();
        if (pid < 0)
        {
            perror("Server Listener: ERROR on fork");
            exit(1);
        }
        if (pid == 0)
        {
            //Connection handler thread
            close(sockfd);
            serverConnection(newsockfd, cli_addr, localSubnet);
            exit(0);
        }
        else
        {
            //Listener no longer needs connection
            close(newsockfd);
        }
    }
}
