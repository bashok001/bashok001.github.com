#include "VPN.h"

//Server certificate and key files
#define CERTF  "certs/server.crt"
#define KEYF  "keys/server.key"
#define CACERT "certs/ca.crt"

void serverConnection (int sockFD, struct sockaddr_in clientSock, char * localSubnet)
{
	int err, pid;
	SSL_CTX* ctx;
	SSL*     ssl;
	X509*    client_cert;
	char    *str, *userName, *password;
	char     buffer [SSL_BUFF_SIZE],
	         symKey[KEY_SIZE + 1],
	         remoteSubnet[4];

	//SSL preliminaries. We keep the certificate and key with the context.
	SSL_load_error_strings();
	SSLeay_add_ssl_algorithms();
	ctx = SSL_CTX_new (SSLv23_server_method());
	if (!ctx) {
		ERR_print_errors_fp(stderr);
		exit(2);
	}

	//Require certificate verification
	SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);
	SSL_CTX_load_verify_locations(ctx, CACERT, NULL);

	//Local certificate/key checks
	if (SSL_CTX_use_certificate_file(ctx, CERTF, SSL_FILETYPE_PEM) <= 0) {
		ERR_print_errors_fp(stderr);
		exit(3);
	}
	if (SSL_CTX_use_PrivateKey_file(ctx, KEYF, SSL_FILETYPE_PEM) <= 0) {
		ERR_print_errors_fp(stderr);
		exit(4);
	}
	if (!SSL_CTX_check_private_key(ctx)) {
		fprintf(stderr, "Private key does not match the certificate public key\n");
		exit(5);
	}

	printf ("Connection from %s:%d\n",
	        inet_ntoa(clientSock.sin_addr), ntohs(clientSock.sin_port));

	//-----------------------------------------------
	//TCP connection is ready. Do server side SSL.
	ssl = SSL_new (ctx);                           CHK_NULL(ssl);
	SSL_set_fd (ssl, sockFD);
	err = SSL_accept (ssl);                        CHK_SSL(err);

	//Get the cipher - opt
	printf ("Established SSL connection using %s\n", SSL_get_cipher (ssl));
	//Get client's certificate (note: beware of dynamic allocation) - opt
	client_cert = SSL_get_peer_certificate (ssl);
	if (client_cert != NULL)
	{
		printf ("Client certificate:\n");

		str = X509_NAME_oneline (X509_get_subject_name (client_cert), 0, 0);
		CHK_NULL(str);
		printf ("\t subject: %s\n", str);
		OPENSSL_free (str);

		str = X509_NAME_oneline (X509_get_issuer_name  (client_cert), 0, 0);
		CHK_NULL(str);
		printf ("\t issuer: %s\n", str);
		OPENSSL_free (str);
		X509_free (client_cert);
	} else {
		//printf ("Client does not have certificate.\n");
		//Using username and password authentication instead
	}

	//-------------------------------------------------------
	//Authenticate client through username and password login
	/*err = SSL_read (ssl, buffer, SSL_BUFF_SIZE - 1);
	CHK_SSL(err); buffer[err] = '\0';

	userName = buffer; //buffer has "[username]:[password]"
	password = memchr(buffer, ':', USERNAME_SIZE);*/

	err = SSL_write (ssl, "Client Verified", strlen("Client Verified"));
	printf("Client logged in from %s:%d\n", inet_ntoa(clientSock.sin_addr), ntohs(clientSock.sin_port));
	bzero(buffer, SSL_BUFF_SIZE); //**Clear password from memory

	//Exchange subnet info
	err = SSL_write (ssl, localSubnet, strlen(localSubnet));  CHK_SSL(err);
	err = SSL_read (ssl, remoteSubnet, 4); CHK_SSL(err);
	remoteSubnet[err] = '\0';
	printf("VPN link between 10.0.%s.0/24 and 10.0.%s.0/24\n",
	       localSubnet, remoteSubnet);

	//-----------------------------------------------------
	//UDP Tunnel
	//Generate truly random symmetric key
	memset(symKey, 0, KEY_SIZE);
	if (!RAND_load_file("/dev/urandom", KEY_SIZE)) {
		CLEAN_SSL_EXIT("Failed to seed OpenSSL RNG", 1);
	}

	if (!RAND_bytes(symKey, KEY_SIZE)) {
		CLEAN_SSL_EXIT("Failed to create OpenSSSL random Key", 1);
	}
	//Send symmetric key to client
	err = SSL_write (ssl, symKey, KEY_SIZE + 1);
	CHK_SSL(err);

	//setup pipe
	int pfd[2];
	if (pipe(pfd) == -1) {
		perror("pipe"); exit(EXIT_FAILURE);
	}

	//fork tunnel process
	pid = fork();
	if (pid < 0)
	{
		perror("Client Connection: ERROR on fork");
		exit(1);
	} else if (pid == 0)
	{
		//tunnel thread
		//--debug printf("Forked tunnel.\n");
		//child tunnel thread
		close(pfd[1]); // Close unused file descriptors

		tunnel(inet_ntoa(clientSock.sin_addr), ntohs(clientSock.sin_port),
		       symKey, localSubnet, remoteSubnet, pfd[0]);
		CLEAN_SSL_EXIT("Tunnel closed.", 0);
	}
	close(pfd[0]); //Close unused read end of pipe

	//--------------------------------------------------
	//Process stdin and server commands
	int childStatus;
	fd_set fdset;

	while (1)
	{

		if (waitpid(pid, &childStatus, WNOHANG) > 0) //Check child status
			CLEAN_SSL_EXIT("Exiting.\n", 0);

		FD_ZERO(&fdset);
		FD_SET(sockFD, &fdset);
		FD_SET(0, &fdset);//stdin
		if (select(sockFD + 1, &fdset, NULL, NULL, NULL) < 0) {
			CLEAN_SSL_EXIT("fd_set select error", 1);
		}

		if (FD_ISSET(sockFD, &fdset)) //SSL receive
		{
			err = SSL_read (ssl, buffer, SSL_BUFF_SIZE - 1); CHK_SSL(err);
			if (err == 0) {
				CLEAN_SSL_EXIT("Connection closed unexpectedly.\n", 1);
			}
			buffer[err] = '\0';
			//printf ("Got %d in message:'%s'\n", err, buffer);

			//Relay TCP message to process
			write(pfd[1], buffer, strlen(buffer));

		} else if (FD_ISSET(0, &fdset)) { //stdin send//xx
			fgets(buffer, SSL_BUFF_SIZE, stdin);
			err = SSL_write (ssl, buffer, strlen(buffer));  CHK_SSL(err);
			if (err == 0) {
				CLEAN_SSL_EXIT("Connection closed unexpectedly.\n", 1);
			}

			//Relay STDIN message to process
			write(pfd[1], buffer, strlen(buffer));
		}
	}

	close(pfd[1]); 	//Reader will see EOF
	SSL_shutdown (ssl);  //send SSL/TLS close_notify
	CLEAN_SSL_EXIT("Closing connection.", 0);
	return;
}