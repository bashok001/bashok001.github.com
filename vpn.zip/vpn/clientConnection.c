#include "VPN.h"

#define CACERT "certs/ca.crt"

void clientConnection (int port, char *serverIP, char *server_CN, char *localSubnet)
{
	int err, sockFD, pid;
	struct sockaddr_in server_addr, client_addr;
	SSL_CTX* ctx;
	SSL*     ssl;
	X509*    server_cert;
	char    *str;
	char	buffer[SSL_BUFF_SIZE],
	        peer_CN[256],
	        symKey[KEY_SIZE + 1],
	        remoteSubnet[4];

	SSLeay_add_ssl_algorithms();
	SSL_load_error_strings();
	ctx = SSL_CTX_new (SSLv23_client_method());        CHK_NULL(ctx);
	CHK_SSL(err);

	//Require certificate verification
	SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);
	SSL_CTX_load_verify_locations(ctx, CACERT, NULL);

	//Create a socket and connect to server using normal socket calls
	sockFD = socket (AF_INET, SOCK_STREAM, 0);       CHK_ERR(sockFD, "socket");
	memset (&server_addr, '\0', sizeof(server_addr));
	server_addr.sin_family      = AF_INET;
	server_addr.sin_addr.s_addr = inet_addr (serverIP);
	server_addr.sin_port        = htons(port);

	err = connect(sockFD, (struct sockaddr*) &server_addr,
	              sizeof(server_addr));                   CHK_ERR(err, "connect");

	int clilen = sizeof(client_addr);
	if (!getsockname(sockFD, (struct sockaddr *)&client_addr, &clilen) == 0 &&
	        client_addr.sin_family == AF_INET && clilen == sizeof(client_addr))
	{
		printf("getsockname() failed. Error! \n");
		exit(-1);
	}

	//-------------------------------------------------
	//TCP conncetion established. Start SSL negotiation.
	ssl = SSL_new (ctx);                         CHK_NULL(ssl);
	SSL_set_fd (ssl, sockFD);
	err = SSL_connect (ssl);                     CHK_SSL(err);

	//Get the cipher - opt
	printf ("SSL connection using %s\n", SSL_get_cipher (ssl));//--debug

	//Get server's certificate (note: beware of dynamic allocation) - opt
	server_cert = SSL_get_peer_certificate (ssl);       CHK_NULL(server_cert);

	//Check that the common name matches the host name
	X509_NAME_get_text_by_NID(X509_get_subject_name(server_cert),
	                          NID_commonName, peer_CN, 256);
	if (strcasecmp(peer_CN, server_CN))
	{
		printf ("Peer Common Name:%s doesn't match server name:%s\n", peer_CN, server_CN);
		CLEAN_SSL_EXIT("Exiting.\n", 0);

	} else
		printf("Common Name verified: %s\n", peer_CN);

	printf ("\nServer certificate:\n");//--debug
	str = X509_NAME_oneline (X509_get_subject_name (server_cert), 0, 0);
	CHK_NULL(str);
	printf ("\t subject: %s\n", str);
	OPENSSL_free (str);
	str = X509_NAME_oneline (X509_get_issuer_name  (server_cert), 0, 0);
	CHK_NULL(str);
	printf ("\t issuer: %s\n", str);
	OPENSSL_free (str);

	X509_free (server_cert);

	err = SSL_read (ssl, buffer, SSL_BUFF_SIZE - 1);
	CHK_SSL(err); buffer[err] = '\0';

	if (strcmp(buffer, "Client Verified") != 0)
	{
		CLEAN_SSL_EXIT("Authentication failed.\n", 1);
	}

	//Exchange subnet info
	err = SSL_read (ssl, remoteSubnet, 4);  CHK_SSL(err);
	err = SSL_write (ssl, localSubnet, strlen(localSubnet));  CHK_SSL(err);
	remoteSubnet[err] = '\0';
	printf("VPN link between 10.0.%s.0/24 and 10.0.%s.0/24\n",
	       localSubnet, remoteSubnet);//--debug

	//-----------------------------------------------------
	//UDP Tunnel
	//First receive initial symmetric key from server
	err = SSL_read (ssl, symKey, KEY_SIZE + 1); CHK_SSL(err);
	symKey[err] = '\0';
	//printf ("Symmetric Key: Got %d chars:'%s'\n", err, symKey);

	//setup pipe
	int pfd[2];
	if (pipe(pfd) == -1) {
		perror("pipe"); exit(EXIT_FAILURE);
	}

	//fork tunnel process
	pid = fork();
	if (pid < 0)
	{
		perror("Client Connection: ERROR on fork");
		exit(1);
	} else if (pid == 0)
	{
		//child tunnel thread
		//printf("Forked tunnel.\n");
		close(pfd[1]); // Close unused write end

		tunnel(inet_ntoa(server_addr.sin_addr),
		       ntohs(client_addr.sin_port), symKey, localSubnet, remoteSubnet, pfd[0]);
		CLEAN_SSL_EXIT("Tunnel closed.", 0);
	}
	close(pfd[0]); //Close unused pipe read end


	//--------------------------------------------------
	//Process stdin and server commands
	int childStatus;
	fd_set fdset;

	while (1)
	{

		if (waitpid(pid, &childStatus, WNOHANG) > 0) //Check child status
			CLEAN_SSL_EXIT("Exiting.\n", 0);

		FD_ZERO(&fdset);
		FD_SET(sockFD, &fdset);
		FD_SET(0, &fdset);//stdin
		if (select(sockFD + 1, &fdset, NULL, NULL, NULL) < 0) {
			CLEAN_SSL_EXIT("fd_set select error", 1);
		}

		//SSL receive
		if (FD_ISSET(sockFD, &fdset))
		{
			err = SSL_read (ssl, buffer, SSL_BUFF_SIZE - 1); CHK_SSL(err);
			if (err == 0) {
				CLEAN_SSL_EXIT("Connection closed unexpectedly.\n", 1);
			}
			buffer[err] = '\0';
			//printf ("Got %d in message:'%s'\n", err, buffer);

			//Relay TCP message to process
			write(pfd[1], buffer, strlen(buffer));

			//stdin: send command to server and process locally
		} else if (FD_ISSET(0, &fdset)) {

			fgets(buffer, SSL_BUFF_SIZE, stdin);
			err = SSL_write (ssl, buffer, strlen(buffer));  CHK_SSL(err);
			if (err == 0) {
				CLEAN_SSL_EXIT("Connection closed unexpectedly.\n", 1);
			}

			//Relay STDIN message to process
			write(pfd[1], buffer, strlen(buffer));
		}
	}

	close(pfd[1]); //Reader will see EOF
	SSL_shutdown (ssl);  //send SSL/TLS close_notify
	CLEAN_SSL_EXIT("Closing connection.", 0);
	return;
}