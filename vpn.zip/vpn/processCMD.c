#include "VPN.h"

int processCMD (int readPipe, char* symKey)
{
	int len;
	char c, buf[SSL_BUFF_SIZE];
	char *nextArg;

	len = read(readPipe, &buf, SSL_BUFF_SIZE);

	if (strstr(buf, "abort") != NULL)
	{
		bzero(symKey, KEY_SIZE);//**clear key from memory
		return 1;
	}

	if ((nextArg = strstr(buf, "setkey")) != NULL)
	{
		nextArg += strlen("setkey") + 1; //skip null terminator
		if (strlen(nextArg) > KEY_SIZE)
		{
			printf("Key size cannot exceed %d.\n", KEY_SIZE);
			return 0;
		} else {
			bzero(symKey, KEY_SIZE);
			memcpy(symKey, nextArg, strlen(nextArg) - 1); //remove newline
			printf("New key manually set:%s.\n", symKey);
			return 0;
		}
	}

	if (strstr(buf, "setrandomkey") != NULL)
	{
		//Generate truly random symmetric key
		memset(symKey, 0, KEY_SIZE);
		if (!RAND_load_file("/dev/urandom", KEY_SIZE)) {
			printf("Failed to seed OpenSSL RNG");
			return 1;
		}

		if (!RAND_bytes(symKey, KEY_SIZE)) {
			printf("Failed to create OpenSSL random Key");
			return 1;
		}
		printf("New random key has been set.\n");
		int k;//--debug
		for (k = 0; k < KEY_SIZE; k++) { printf("%c", symKey[k]); }
		printf(".\n");
		return 0;
	}

	if ((nextArg = strstr(buf, "message")) != NULL)
	{
		printf("%s", nextArg);
		return 0;
	}
	return 0;
}