#ifndef VPN_H
#define VPN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <unistd.h>
#include <termios.h>
#include <memory.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <linux/if_tun.h>
#include <sys/ioctl.h>

#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/rand.h>
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define CIPHER_BLOCK_SIZE 128
#define PLAIN_BUFF_MAX 20*CIPHER_BLOCK_SIZE //For convenience, make multiple of block size
#define CIPHER_BUFF_MAX  PLAIN_BUFF_MAX + CIPHER_BLOCK_SIZE //extra block for padding
#define HASH_SIZE 32 //in bytes, actually 256 bits SHA256_LEN 
#define KEY_SIZE 16 //in bytes, actually 128 AES128_CBC
#define IV_SIZE 16 //in bytes, actually 128 bits
#define CIPHER_IV_BUFF_MAX CIPHER_BUFF_MAX + IV_SIZE
#define CIPHER_IV_HMAC_MAX CIPHER_IV_BUFF_MAX + HASH_SIZE

#define SSL_BUFF_SIZE 4096
#define TCP_BUFF_SIZE SSL_BUFF_SIZE

#define CLEAN_SSL_EXIT(x, y) do { printf(x); close (sockFD); SSL_free (ssl); SSL_CTX_free (ctx); exit(y);} while (0)
#define CHK_NULL(x) if ((x)==NULL) exit (1)
#define CHK_ERR(err,s) if ((err)==-1) { perror(s); exit(1); }
#define CHK_SSL(err) if ((err)==-1) { ERR_print_errors_fp(stderr); exit(2); }

#define PERROR(x) do { perror(x); exit(1); } while (0)
#define EXIT_CLEAN_CTX(x) do { printf(x); EVP_CIPHER_CTX_cleanup(&ctx); HMAC_CTX_cleanup(&mdctx); close(readPipe); memset(symKey, 0, KEY_SIZE); return;} while (0)
#define ERROR(x, args ...) do { fprintf(stderr,"ERROR:" x, ## args); exit(1); } while (0)

void serverListener ( int port, char * localSubnet);
void serverConnection (int sock, struct sockaddr_in clientSock, char * localSubnet);
void serverProcessCommands (int sockFD, struct sockaddr_in clientSock, char * buffer);
void clientConnection (int port, char * serverIP, char *server_CN,
                       char * localSubnet);
void tunnel (char* ip, int port, char* symKey, char *localSubnet,
             char *remoteSubnet, int readPipe);
int authenticate(char* userPwd);
int processCMD (int readPipe, char* symKey);

#endif