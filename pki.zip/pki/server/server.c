#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <memory.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <openssl/rsa.h>
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define CA_DIR "../ca/"
#define SERVER_CERT "server.crt"
#define SERVER_KEY  "server.key"
#define CA_CERT CA_DIR "ca.crt"

#define PORT 9980

int createTCPSocket(void) {
  int sock;
  if ((sock = socket (AF_INET, SOCK_STREAM, 0)) == -1) {
    printf("Error at socket creation.\n");
    exit(-1);
  }
  return sock;
}

int createUDPSocket(void) {
  int sock;
  if ((sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
    printf("Error at socket creation.\n");
    exit(-1);
  }
  return sock;
}

void bindToPort (int socket, int portNumber) {
  struct sockaddr_in hostSocketInfo;
  memset((char *) &hostSocketInfo, 0, sizeof(hostSocketInfo));

  hostSocketInfo.sin_family = AF_INET;
  hostSocketInfo.sin_port = htons(portNumber);
  hostSocketInfo.sin_addr.s_addr = htonl(INADDR_ANY);

  //Bind and start listening to the 'portNumber' specified by 'sin_port' in 'hostSocketInfo'
  if (bind(socket, (struct sockaddr *)&hostSocketInfo, sizeof(hostSocketInfo)) == -1) {
    printf("Error while binding to a port\n");
    exit(-1);
  }
}

void decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
             unsigned char *iv, unsigned char *plaintext) {
  EVP_CIPHER_CTX *ctx;
  int len;
  int plaintext_len;
  ERR_load_crypto_strings();

  /* Create and initialise the context */
  if (!(ctx = EVP_CIPHER_CTX_new())) {
    printf("Error while creating the context.\n");
    exit(-1);
  }

  /* Initialise the decryption operation. */
  if (!EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv)) {
    printf("Error while initializing the decryption context.\n");
    exit(-1);
  }

  /* Provide the message to be decrypted, and obtain the plaintext output.
   * EVP_DecryptUpdate can be called multiple times if necessary
   */
  if (!EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len)) {
    printf("Error while decrypting the data.\n");
    exit(-1);
  }
  plaintext_len = len;

  /* Finalise the decryption. Further plaintext bytes may be written at
   * this stage.
   */
  EVP_DecryptFinal_ex(ctx, plaintext + len, &len);
  plaintext_len += len;

  /* Clean up */
  EVP_CIPHER_CTX_free(ctx);
}

/*
  Compares 'hmac' to 'calculatedHmac'. If it's an absolute match, returns 1.
  Otherwise, returns 0.
*/
int verifyHMAC(char *hmac, char *calculatedHmac, int hmacLen) {
  int i;
  for (i = 0; i < hmacLen; ++i) {
    if (hmac[i] != calculatedHmac[i])
      return 0;
  }
  return 1;
}

int main ()
{
  int err;
  int listen_sd;
  int sd;
  struct sockaddr_in sa_serv;
  struct sockaddr_in sa_cli;
  size_t client_len;
  SSL_CTX* ctx;
  SSL*     ssl;
  X509*    client_cert;
  char*    str;
  char buf[32];
  SSL_METHOD *meth;

  unsigned char hmac[32];
  unsigned char calculatedHmac[32];
  unsigned int calculatedHmacLen;
  unsigned char iv[32];
  unsigned char key[32];

  char cipherText[64];
  char plainText[50];
  char message[300];
  ssize_t messageLength;
  memset((char *) cipherText, 0, sizeof(cipherText));
  memset((char *) plainText, 0, sizeof(plainText));
  memset((char *) message, 0, sizeof(message));


  /* SSL preliminaries. We keep the certificate and key with the context. */

  SSL_load_error_strings();
  SSLeay_add_ssl_algorithms();
  meth = SSLv23_server_method();
  ctx = SSL_CTX_new (meth);
  if (!ctx) {
    ERR_print_errors_fp(stderr);
    exit(2);
  }

  SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL); /* whether verify the certificate */
  SSL_CTX_load_verify_locations(ctx, CA_CERT, NULL);

  if (SSL_CTX_use_certificate_file(ctx, SERVER_CERT, SSL_FILETYPE_PEM) <= 0) {
    ERR_print_errors_fp(stderr);
    exit(3);
  }
  if (SSL_CTX_use_PrivateKey_file(ctx, SERVER_KEY, SSL_FILETYPE_PEM) <= 0) {
    ERR_print_errors_fp(stderr);
    exit(4);
  }

  if (!SSL_CTX_check_private_key(ctx)) {
    fprintf(stderr, "Private key does not match the certificate public key\n");
    exit(5);
  }

  /* ----------------------------------------------- */
  /* Prepare TCP socket for receiving connections */

  listen_sd = createTCPSocket();
  bindToPort(listen_sd, PORT);

  /* Receive a TCP connection. */

  if ( listen (listen_sd, 5) == -1) {
    printf("Failed to mark socket to listen.\n");
    exit(-1);
  }

  client_len = sizeof(sa_cli);
  if ((sd = accept (listen_sd, (struct sockaddr*) &sa_cli, &client_len)) == -1) {
    printf("Failed to accept data from the socket.\n");
    exit(-1);
  }

  close (listen_sd);

  printf ("Connection from %lx, port %x\n", sa_cli.sin_addr.s_addr, sa_cli.sin_port);

  /* ----------------------------------------------- */
  /* TCP connection is ready. Do server side SSL. */

  ssl = SSL_new (ctx);//CHK_NULL(ssl);
  SSL_set_fd (ssl, sd);
  err = SSL_accept (ssl);//CHK_SSL(err);

  /* Get the cipher - opt */

  printf ("SSL connection using %s\n", SSL_get_cipher (ssl));

  /* DATA EXCHANGE - Receive message and send reply. */
  err = SSL_read (ssl, buf, sizeof(buf));//CHK_SSL(err);
  printf ("Got %d chars:'%s'\n", err, buf);
  strncpy(key, buf, 32);

  /* Clean up. */
  close (sd);
  SSL_free (ssl);
  SSL_CTX_free (ctx);

  listen_sd = createUDPSocket();
  bindToPort(listen_sd, PORT);

  //recvfrom() will try 'socket' to fill 'message' with 'messageLength' bytes (Max: 300, sizeof(message))
  if ((messageLength = recvfrom(listen_sd, message, sizeof(message), 0, (struct sockaddr *)&sa_cli, &client_len)) == -1) {
    printf("Error while recieving packets.\n");
    exit(-1);
  }

  printf("Received packet from %s:%d\n", inet_ntoa(sa_cli.sin_addr), ntohs(sa_cli.sin_port));

  //Protection against completely empty datagrams from crashing the server.
  //Nothing to do with the functionality
  if (messageLength - 64 < 0)
    messageLength = 64;

  //Get IV from the message. First 256 bits of the message
  memcpy(iv, message, sizeof(iv));

  //Get HMAC from the message. Second 256 bits (257-512 bits) of the message
  memcpy(hmac, message + 32 * sizeof(char), sizeof(hmac));

  //Rest of the message is the encrypted payload data.
  memcpy(cipherText, message + 64 * sizeof(char), messageLength - 64);

  //Calculate HMAC of the encrypted payload
  HMAC(EVP_sha256(), key, sizeof(key), cipherText, strlen(cipherText), calculatedHmac, &calculatedHmacLen);

  //Verify if it matches the HMAC extracted from the message.
  if (!verifyHMAC(hmac, calculatedHmac, calculatedHmacLen)) {
    printf("Hash mismatch. Terminating further operations.\n");
    exit(-1);
  }
  else
    printf("Hash matched. Message Authenticated. \n");

  //If everything is good, decrypt the data.
  decrypt(cipherText, sizeof(cipherText), key, iv, plainText);
  printf("Decrypted Data: %s\n", plainText);

  // Close the socket
  close(listen_sd);
  return 0;
}
