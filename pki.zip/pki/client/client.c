#include <unistd.h>
#include <stdio.h>
#include <memory.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#define SERVER_IP "<SERVER_IP>"
#define SERVER_PORT 9980
#define MSG "This is the encrypted message crossing the channnn"

#define CHK_NULL(x) if ((x)==NULL) exit (1)
#define CHK_ERR(err,s) if ((err)==-1) { perror(s); exit(1); }
#define CHK_SSL(err) if ((err)==-1) { ERR_print_errors_fp(stderr); exit(2); }

#define CA_DIR "../ca/"
#define CA_CERT CA_DIR "ca.crt"

void cleanUp(int sd,SSL* ssl,SSL_CTX* ctx)
{
    SSL_shutdown (ssl);  /* send SSL/TLS close_notify */

    /* Clean up. */

    close (sd);
    SSL_free (ssl);
    SSL_CTX_free (ctx);
}

void getRandom(int length, char* data) {
  //Open /dev/urandom and get the entropy data
  FILE* random = fopen("/dev/urandom", "r");
  //Read 'length' chars from the file using 'random' fd into 'data'
  fread(data, sizeof(unsigned char)*length, 1, random);
  printf("IN RAND: %s\n\n", data);
  fclose(random);
}

int createSocket(void) {
  int sock;
  //AF_INET: Internet socket, SOCK_DGRAM: Datagram delivery system
  //IPPROTO_UDP: Will use UDP Protocol
  //socket() will intialize sock to the defined parameters
  if ((sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
    printf("Error at socket creation.\n");
    exit(-1);
  }

  return sock;
}

void setupSocketInfo(struct sockaddr_in *socket, char* IP, int portNumber) {
  memset((char *) socket, 0, sizeof(socket));
  socket->sin_family = AF_INET;
  socket->sin_port = htons(portNumber);
  //inet_aton() is used to convert a string in dotted-decimal ASCII notation
  //from IP to a binary address, sin_addr
  if (inet_aton(IP, &socket->sin_addr) == 0) {
    printf("IP conversion failed.\n");
    exit(-1);
  }
}

int encryptData(unsigned char *plaintext, int plaintextLen, unsigned char *key,
                unsigned char *iv, unsigned char *ciphertext) {
  EVP_CIPHER_CTX *ctx;
  int len;
  int ciphertext_len;
  ERR_load_crypto_strings();

  /* Create and initialise the context */
  if (!(ctx = EVP_CIPHER_CTX_new()))
    printf("Context Initialization Error");

  /* Initialise the encryption operation.*/
  if (!EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
    printf("Encryption Initialization Error");

  /* Provide the message to be encrypted, and obtain the encrypted output.
   * EVP_EncryptUpdate can be called multiple times if necessary
   */
  if (!EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintextLen))
    printf("Encryption Operation Error");
  ciphertext_len = len;

  /* Finalise the encryption. Further ciphertext bytes may be written at
   * this stage.
   */
  EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
  ciphertext_len += len;

  /* Clean up */
  EVP_CIPHER_CTX_free(ctx);

  return ciphertext_len;
}

void createUdpMessage(unsigned char *iv, int ivLen, unsigned char *hmac, int hmacLen, unsigned char *ciphertext, int cipherTextLen, unsigned char* message) {
  mempcpy(mempcpy(mempcpy(message, iv, ivLen), hmac, hmacLen), ciphertext, cipherTextLen);
}

int main ()
{
  int err;
  int sd;
  struct sockaddr_in sa;
  SSL_CTX* ctx;
  SSL*     ssl;
  X509*    server_cert;
  char*    str;
  char     buf [4096];
  SSL_METHOD *meth;

  char key[32];
  char iv[32];
  memset((char *) key, 0, sizeof(key));
  memset((char *) iv, 0, sizeof(iv));
 
  SSLeay_add_ssl_algorithms();
  meth = SSLv23_client_method();
  SSL_load_error_strings();
  ctx = SSL_CTX_new (meth);                        CHK_NULL(ctx);

  CHK_SSL(err);


  SSL_CTX_set_verify(ctx,SSL_VERIFY_PEER,NULL);
  SSL_CTX_load_verify_locations(ctx,CA_CERT,NULL);
  
  /* ----------------------------------------------- */
  /* Create a socket and connect to server using normal socket calls. */
  
  sd = socket (AF_INET, SOCK_STREAM, 0);       CHK_ERR(sd, "socket");
 
  memset (&sa, '\0', sizeof(sa));
  sa.sin_family      = AF_INET;
  sa.sin_addr.s_addr = inet_addr (SERVER_IP);   /* Server IP */
  sa.sin_port        = htons     (SERVER_PORT);          /* Server Port number */
  
  err = connect(sd, (struct sockaddr*) &sa,
    sizeof(sa));                   CHK_ERR(err, "connect");

  /* ----------------------------------------------- */
  /* Now we have TCP conncetion. Start SSL negotiation. */
  
  ssl = SSL_new (ctx);                         CHK_NULL(ssl);    
  SSL_set_fd (ssl, sd);
  err = SSL_connect (ssl);                     CHK_SSL(err);
    
  /* Following two steps are optional and not required for
     data exchange to be successful. */
  
  /* Get the cipher - opt */

  printf ("SSL connection using %s\n", SSL_get_cipher (ssl));
  
  /* Get server's certificate (note: beware of dynamic allocation) - opt */

  server_cert = SSL_get_peer_certificate (ssl);       CHK_NULL(server_cert);
  printf ("Server certificate:\n");
  
  str = X509_NAME_oneline (X509_get_subject_name (server_cert),0,0);
  CHK_NULL(str);
  printf ("\t subject: %s\n", str);
  OPENSSL_free (str);

  str = X509_NAME_oneline (X509_get_issuer_name  (server_cert),0,0);
  CHK_NULL(str);
  printf ("\t issuer: %s\n", str);
  OPENSSL_free (str);

  /* We could do all sorts of certificate verification stuff here before
     deallocating the certificate. */

  X509_free (server_cert);
  getRandom(sizeof(key), key);
  printf("%s\n\n", key);
  /* --------------------------------------------------- */
   /* DATA EXCHANGE - Send a message and receive a reply. */
    err = SSL_write (ssl, key, sizeof(key));

  cleanUp(sd,ssl,ctx);


  struct sockaddr_in si_other;
  char ciphertext[100];
  unsigned char hmac[100];
  unsigned int hmaclen;
  unsigned int cipherTextLen;
  char udpMessage[128];

  memset((char *) udpMessage, 0, sizeof(udpMessage));
  int slen = sizeof(si_other);


    // Create a socket
  sd = createSocket();
  //Set all the information needed for the connection
  setupSocketInfo(&si_other, SERVER_IP, SERVER_PORT);
  //Get key for encryption functions from command line params

  //Get random number (ivLen bytes - 256 bits) for IV 
  getRandom(sizeof(iv), iv);
  //Encrypt MSG that returns 'cipherTextLen' bytes
  cipherTextLen = encryptData(MSG, sizeof(MSG), key, iv, ciphertext);
  //Calculate hash for ciphertext
  HMAC(EVP_sha256(), key, sizeof(key), ciphertext, cipherTextLen, hmac, &hmaclen);

  createUdpMessage(iv, sizeof(iv), hmac, hmaclen, ciphertext, cipherTextLen, udpMessage);

  printf("\nSending a packet.\n");
  //sendto(): Send 'sizeof(udpMessage)' bytes from 'udpMessage' to 'socket', with no flags (0).
  //The receiver is specified in si_other, which contains slen byte.
  if (sendto(sd, udpMessage, sizeof(udpMessage), 0, (struct sockaddr *)&si_other, slen) == -1) {
    perror("socket");
    printf("Sending failed.\n");
    exit(-1);
  }
  //Close the socket
  close(socket);
  
  return 0;
}