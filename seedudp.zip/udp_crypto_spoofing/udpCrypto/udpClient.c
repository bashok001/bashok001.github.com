#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/types.h>
#include <sys/socket.h>

#define BUFLEN 512
#define PORT 9930

// Example: #define SRV_IP "127.0.0.1"
#define SRV_IP "<SERVER_IP>"
#define MSG "This is the message crossing the channel"

int createSocket(void) {
	int sock;
	//AF_INET: Address Family used for Internet socket
	//SOCK_DGRAM: Datagram sockets
	//IPPROTO_UDP: Will use UDP Protocol
	//socket() will intialize sock to the defined parameters
	if ((sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
		printf("Socket creation error.\n");
		exit(-1);
	}
	return sock;
}

void setupSocketInfo(struct sockaddr_in *socket, char* IP, int portNumber) {
	memset((char *) socket, 0, sizeof(socket));
	socket->sin_family = AF_INET;
	socket->sin_port = htons(portNumber);

	//inet_aton() is used to convert a string in dotted-decimal ASCII notation
	//from IP to a binary address, sin_addr
	if (inet_aton(IP, &socket->sin_addr) == 0) {
		printf("IP conversion failed.\n");
		exit(-1);
	}
}

int main(void) {
	struct sockaddr_in serverSocketInfo;
	int socket, socketInfoLen;
	char buffer[BUFLEN];
		
	socketInfoLen = sizeof(serverSocketInfo);	

	// Create a socket
	socket = createSocket();

	//Set all the information needed for the connection
	setupSocketInfo(&serverSocketInfo, SRV_IP, PORT);

	//Load the MSG into buffer, buf
	sprintf(buffer, MSG);

	printf("Sending a packet.\n");
	
	//sendto(): Send 'BUFLEN' bytes from 'buffer' to 'socket', with no flags (0).
	//The receiver is specified in 'serverSocketInfo', size of which is 'socketInfoLen'.
	if (sendto(socket, buffer, BUFLEN, 0, (struct sockaddr *)&serverSocketInfo, socketInfoLen) == -1) {
		perror("Socket sendto failed.");
		exit(-1);
	}

	//Close the socket fd.
	close(socket);
	return 0;
}
