#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <openssl/evp.h>
#include <openssl/hmac.h>

#define PORT 9940

int createSocket(void) {
  int sock;
  //AF_INET: Internet socket, SOCK_DGRAM: Datagram delivery system
  //IPPROTO_UDP: Will use UDP Protocol
  //socket() will intialize sock to the defined parameters
  if ((sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
    printf("Error at socket creation.\n");
    exit(-1);
  }

  return sock;
}

void bindToPort (int socket, int portNumber) {
  struct sockaddr_in hostSocketInfo;
  memset((char *) &hostSocketInfo, 0, sizeof(hostSocketInfo));

  hostSocketInfo.sin_family = AF_INET;
  hostSocketInfo.sin_port = htons(portNumber);
  hostSocketInfo.sin_addr.s_addr = htonl(INADDR_ANY);

  //Bind and start listening to the 'portNumber' specified by 'sin_port' in 'hostSocketInfo'
  if (bind(socket, (struct sockaddr *)&hostSocketInfo, sizeof(hostSocketInfo)) == -1) {
    printf("Error while binding to a port\n");
    exit(-1);
  }
}

void decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
             unsigned char *iv, unsigned char *plaintext) {
  EVP_CIPHER_CTX *ctx;
  int len;
  int plaintext_len;
  ERR_load_crypto_strings();

  /* Create and initialise the context */
  if (!(ctx = EVP_CIPHER_CTX_new())) {
    printf("Error while creating the context.\n");
    exit(-1);
  }

  /* Initialise the decryption operation. */
  if (!EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv)) {
    printf("Error while initializing the decryption context.\n");
    exit(-1);
  }

  /* Provide the message to be decrypted, and obtain the plaintext output.
   * EVP_DecryptUpdate can be called multiple times if necessary
   */
  if (!EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len)) {
    printf("Error while decrypting the data.\n");
    exit(-1);
  }
  plaintext_len = len;

  /* Finalise the decryption. Further plaintext bytes may be written at
   * this stage.
   */
  if (!EVP_DecryptFinal_ex(ctx, plaintext + len, &len)) {
    ERR_print_errors_fp(stderr);
    printf("Error while finalizing the decryption %s,%d\n", plaintext, len);
    printf("Verify the length of cipher text provided. If you're using UDP, read the exact length of cipher text.\n");
  }
  plaintext_len += len;

  /* Clean up */
  EVP_CIPHER_CTX_free(ctx);
}

/*
  Compares 'hmac' to 'calculatedHmac'. If it's an absolute match, returns 1.
  Otherwise, returns 0.
*/
int verifyHMAC(char *hmac, char *calculatedHmac, int hmacLen) {
  int i;
  for (i = 0; i < hmacLen; ++i) {
    if (hmac[i] != calculatedHmac[i])
      return 0;
  }
  return 1;
}

int main(int argc, char *argv[]) {
  struct sockaddr_in clientSocketInfo;
  int clientSockLength, socket;

  unsigned char hmac[32];
  unsigned int hmaclen;
  unsigned char calculatedHmac[32];
  unsigned int calculatedHmacLen;
  unsigned char iv[32];
  unsigned char* key;

  char cipherText[64];
  char plainText[50];
  char message[300];
  ssize_t messageLength;
  memset((char *) cipherText, 0, sizeof(cipherText));
  memset((char *) plainText, 0, sizeof(plainText));
  memset((char *) message, 0, sizeof(message));

  //Get key for encryption functions from command line params
  key = argv[1];
  clientSockLength = sizeof(clientSocketInfo);

  // Create a socket
  socket = createSocket();

  // Bind this app through 'socket' to listen to 'PORT'
  bindToPort(socket, PORT);

  while (1) {
    //recvfrom() will try 'socket' to fill 'message' with 'messageLength' bytes (Max: 300, sizeof(message))
    if ((messageLength = recvfrom(socket, message, sizeof(message), 0, (struct sockaddr *)&clientSocketInfo, &clientSockLength)) == -1) {
      printf("Error while recieving packets.\n");
      exit(-1);
    }

    printf("Received packet from %s:%d\n", inet_ntoa(clientSocketInfo.sin_addr), ntohs(clientSocketInfo.sin_port));

    //Protection against completely empty datagrams from crashing the server.
    //Nothing to do with the functionality
    if (messageLength - 64 < 0)
      messageLength = 64;

    //Get IV from the message. First 256 bits of the message
    memcpy(iv, message, sizeof(iv));

    //Get HMAC from the message. Second 256 bits (257-512 bits) of the message
    memcpy(hmac, message + 32 * sizeof(char), sizeof(hmac));

    //Rest of the message is the encrypted payload data.
    memcpy(cipherText, message + 64 * sizeof(char), messageLength - 64);

    //Calculate HMAC of the encrypted payload
    HMAC(EVP_sha256(), key, sizeof(key), cipherText, strlen(cipherText), calculatedHmac, &calculatedHmacLen);

    //Verify if it matches the HMAC extracted from the message.
    if (!verifyHMAC(hmac, calculatedHmac, calculatedHmacLen)) {
      printf("Hash mismatch. Terminating further operations.\n");
      continue;
    }
    else
      printf("Hash matched. Message Authenticated. \n");

    //If everything is good, decrypt the data.
    decrypt(cipherText, sizeof(cipherText), key, iv, plainText);
    printf("Decrypted Data: %s\n", plainText);
  }

  // Close the socket
  close(socket);
  return 0;
}