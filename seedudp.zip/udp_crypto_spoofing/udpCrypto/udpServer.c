#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/types.h>
#include <sys/socket.h>

#define BUFLEN 512
#define PORT 9930

int createSocket(void) {
    int sock;
    //AF_INET: Internet socket, SOCK_DGRAM: Datagram delivery system
    //IPPROTO_UDP: Will use UDP Protocol
    //socket() will intialize sock to the defined parameters
    if ((sock=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP))==-1){
        printf("Error at socket creation.\n");
        exit(-1);
    }

    return sock;
}

void bindToPort (int socket, int portNumber) {
  struct sockaddr_in hostSocketInfo;
  memset((char *) &hostSocketInfo, 0, sizeof(hostSocketInfo));

  hostSocketInfo.sin_family = AF_INET;
  hostSocketInfo.sin_port = htons(portNumber);
  hostSocketInfo.sin_addr.s_addr = htonl(INADDR_ANY);

  //Bind and start listening to the 'portNumber' specified by 'sin_port' in 'hostSocketInfo'
  if (bind(socket, (struct sockaddr *)&hostSocketInfo, sizeof(hostSocketInfo)) == -1) {
    printf("Error while binding to a port\n");
    exit(-1);
  }
}

int main(void) {
    struct sockaddr_in clientSocketInfo;
    int clientSockLength = sizeof(clientSocketInfo);
    char buf[BUFLEN];
    memset(buf, 0, BUFLEN);
    
    // Create a socket
    int socket = createSocket();

    // Bind this app through 'socket' to listen to 'PORT'
    bindToPort(socket, PORT);

    while (1) {
        //recvfrom() uses 'socket' to fill 'buf' with 'BUFLEN' bytes
        if (recvfrom(socket, buf, BUFLEN, 0, (struct sockaddr *)&clientSocketInfo, &clientSockLength)==-1){
            printf("Error while recieving packets.\n");
            exit(-1);
        }
        printf("Received packet from %s:%d\nData: %s\n\n", inet_ntoa(clientSocketInfo.sin_addr), ntohs(clientSocketInfo.sin_port), buf);
    }
    
    // Close the socket
    close(socket);
    return 0;
}
