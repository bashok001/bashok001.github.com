#define _GNU_SOURCE
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <openssl/evp.h>
#include <openssl/hmac.h>

#define BUFLEN 512
#define PORT 9930

// Example:#define SRV_IP "192.168.0.14"
#define SRV_IP "<SERVER_IP>"

#define MSG "This is the encrypted message crossing the channel"

#define CORRUPT_MSG 0

int createSocket(void) {
	int sock;
	//AF_INET: Internet socket, SOCK_DGRAM: Datagram delivery system
	//IPPROTO_UDP: Will use UDP Protocol
	//socket() will intialize sock to the defined parameters
	if ((sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
		printf("Error at socket creation.\n");
		exit(-1);
	}

	return sock;
}

void setupSocketInfo(struct sockaddr_in *socket, char* IP, int portNumber) {
	memset((char *) socket, 0, sizeof(socket));
	socket->sin_family = AF_INET;
	socket->sin_port = htons(portNumber);
	//inet_aton() is used to convert a string in dotted-decimal ASCII notation
	//from IP to a binary address, sin_addr
	if (inet_aton(IP, &socket->sin_addr) == 0) {
		printf("IP conversion failed.\n");
		exit(-1);
	}
}

void getRandom(int length, unsigned char* data) {
	data = (unsigned char *) malloc(sizeof(unsigned char) * length);
	//Open /dev/urandom and get the entropy data
	FILE* random = fopen("/dev/urandom", "r");

	//Read 'length' chars from the file using 'random' fd into 'data'
	fread(data, sizeof(unsigned char)*length, 1, random);
	fclose(random);
}

int encryptData(unsigned char *plaintext, int plaintextLen, unsigned char *key,
                unsigned char *iv, unsigned char *ciphertext) {
	EVP_CIPHER_CTX *ctx;
	int len;
	int ciphertext_len;
	ERR_load_crypto_strings();

	/* Create and initialise the context */
	if (!(ctx = EVP_CIPHER_CTX_new()))
		printf("Context Initialization Error");

	/* Initialise the encryption operation.*/
	if (!EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
		printf("Encryption Initialization Error");

	/* Provide the message to be encrypted, and obtain the encrypted output.
	 * EVP_EncryptUpdate can be called multiple times if necessary
	 */
	if (!EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintextLen))
		printf("Encryption Operation Error");
	ciphertext_len = len;

	/* Finalise the encryption. Further ciphertext bytes may be written at
	 * this stage.
	 */
	if (!EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
		printf("Encryption Finalization Error");;
	ciphertext_len += len;

	/* Clean up */
	EVP_CIPHER_CTX_free(ctx);

	return ciphertext_len;
}

//Helper function to flip first bit of 'text'
//Used to emulate corruption on a noisy channel
void flipFirstBit(char *text) {
	int number = text[0];
	number ^= 1 << 0;
	text[0] = number;
}

/*
Helper function used to construct a UDP Packet in layers
---------------------------------
|	IV (ivLen bytes)	|
---------------------------------
|	HMAC ('hmacLen' bytes)	|
---------------------------------
|				|
|	   Encrypted Data 	|	
|     ('cipherTextLen' bytes)	|
|				|
---------------------------------
*/
void createUdpMessage(unsigned char *iv, int ivLen, unsigned char *hmac, int hmacLen, unsigned char *ciphertext, int cipherTextLen, unsigned char* message) {
	mempcpy(mempcpy(mempcpy(message, iv, ivLen), hmac, hmacLen), ciphertext, cipherTextLen);
}

int main(int argc, char *argv[]) {
	struct sockaddr_in si_other;
	int slen, socket;
	char ciphertext[100];
	unsigned char hmac[100];
	unsigned int hmaclen;
	unsigned int cipherTextLen;
	char udpMessage[128];

	int ivLen = 32;
	unsigned char* iv;
	unsigned char* key;

	memset((char *) udpMessage, 0, sizeof(udpMessage));
	slen = sizeof(si_other);

	// Create a socket
	socket = createSocket();
	//Set all the information needed for the connection
	setupSocketInfo(&si_other, SRV_IP, PORT);
	//Get key for encryption functions from command line params
	key = argv[1];
	//Get random number (ivLen bytes - 256 bits) for IV 
	getRandom(ivLen, iv);
	//Encrypt MSG that returns 'cipherTextLen' bytes
	cipherTextLen = encryptData(MSG, sizeof(MSG), key, iv, ciphertext);
	//Calculate hash for ciphertext
	HMAC(EVP_sha256(), key, sizeof(key), ciphertext, cipherTextLen, hmac, &hmaclen);

	//Emulate corrupt data on noisy channel
	if (CORRUPT_MSG) {
		flipFirstBit(ciphertext);
	}
	
	createUdpMessage(iv, ivLen, hmac, hmaclen, ciphertext, cipherTextLen, udpMessage);

	printf("\nSending a packet.\n");
	//sendto(): Send 'sizeof(udpMessage)' bytes from 'udpMessage' to 'socket', with no flags (0).
	//The receiver is specified in si_other, which contains slen byte.
	if (sendto(socket, udpMessage, sizeof(udpMessage), 0, (struct sockaddr *)&si_other, slen) == -1) {
		perror("socket");
		printf("Sending failed.\n");
		exit(-1);
	}
	//Close the socket
	close(socket);
	return 0;
}
