#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <openssl/evp.h>
#include <openssl/hmac.h>

#define BUFLEN 512
#define PORT 9930

// Example: #define SRV_IP "192.168.0.14"
#define SRV_IP "<SERVER_IP>"

#define MSG "This is the encrypted message crossing the channel"

#define KEY "U0VFRFdvcmtzaG9wSW5KdW5lMTVBdFN5cmFjdXNlVW5pdmVyc2l0eQ"
#define IV "QXNob2tUYXVnaHRUaGlzQXRTVQ"

int createSocket(void) {
    int sock;
    if ((sock=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP))==-1){
        printf("Error at socket creation.\n");
        exit(-1);
    }
    return sock;
}

void setupSocketInfo(struct sockaddr_in *socket, char* IP, int portNumber){
	memset((char *) socket, 0, sizeof(socket));
	socket->sin_family = AF_INET;	
	socket->sin_port = htons(portNumber);
	if (inet_aton(IP, &socket->sin_addr)==0) {
		printf("IP conversion failed.\n");
		exit(-1);
	}
}

void encrypt(unsigned char *plaintext, int plaintextLen, unsigned char *key,
  unsigned char *iv, unsigned char *ciphertext) {
	
	EVP_CIPHER_CTX *ctx;
	int len;
	int ciphertext_len;
	ERR_load_crypto_strings();
  /* Create and initialise the context */
  if(!(ctx = EVP_CIPHER_CTX_new()))
    printf("Context Initialization Error");

  /* Initialise the encryption operation.*/
  if(!EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
    printf("Encryption Initialization Error");

  /* Provide the message to be encrypted, and obtain the encrypted output.
   * EVP_EncryptUpdate can be called multiple times if necessary
   */

  if(!EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintextLen))
    printf("Encryption Operation Error");
  ciphertext_len = len;

  /* Finalise the encryption. Further ciphertext bytes may be written at
   * this stage.
   */
  if(!EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
    printf("Encryption Finalization Error");;
  ciphertext_len += len;

  /* Clean up */
  EVP_CIPHER_CTX_free(ctx);
}

int main(void) {
	struct sockaddr_in si_other;
	int slen, socket;
	char ciphertext[100];
	unsigned char hmac[100];
	unsigned int hmaclen;

	hmaclen = sizeof(hmac);
	slen = sizeof(si_other);
	socket = createSocket();
	setupSocketInfo(&si_other, SRV_IP, PORT);

	encrypt(MSG, sizeof(MSG), KEY, IV, ciphertext);
	HMAC(EVP_sha256(), KEY, sizeof(KEY), MSG, strlen(MSG), hmac, &hmaclen);

	if (sendto(socket, hmac, hmaclen, 0, (struct sockaddr *)&si_other, slen) < 0){
		perror("HMAC");
		printf("Sending HMAC failed.\n");
		exit(-1);
	}
	printf("\nSending a packet.\n");

	if (sendto(socket, ciphertext, sizeof(ciphertext), 0, (struct sockaddr *)&si_other, slen)==-1){
		perror("socket");
		printf("Sending failed.\n");
		exit(-1);
	}

	close(socket);
	return 0;
}