#define _GNU_SOURCE
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <openssl/evp.h>
#include <openssl/hmac.h>

#define BUFLEN 512
#define PORT 9930

// Example:
#define SRV_IP "192.168.0.14"
//#define SRV_IP "<SERVER_IP>"

#define MSG "This is the encrypted message crossing the channel"

#define CORRUPT_MSG 0

int createSocket(void) {
	int sock;

	//AF_INET: Internet socket, SOCK_DGRAM: Datagram delivery system
	//IPPROTO_UDP: Will use UDP Protocol
	//socket() will intialize sock to the defined parameters
	if ((sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
		printf("Error at socket creation.\n");
		exit(-1);
	}

	return sock;
}

void setupSocketInfo(struct sockaddr_in *socket, char* IP, int portNumber) {
	memset((char *) socket, 0, sizeof(socket));
	socket->sin_family = AF_INET;
	socket->sin_port = htons(portNumber);
	if (inet_aton(IP, &socket->sin_addr) == 0) {
		printf("IP conversion failed.\n");
		exit(-1);
	}
}

void getRandom(int length, unsigned char* data) {
	data = (unsigned char *) malloc(sizeof(unsigned char) * length);
	FILE* random = fopen("/dev/urandom", "r");
	fread(data, sizeof(unsigned char)*length, 1, random);
	fclose(random);
}

int encryptData(unsigned char *plaintext, int plaintextLen, unsigned char *key,
                unsigned char *iv, unsigned char *ciphertext) {
	EVP_CIPHER_CTX *ctx;
	int len;
	int ciphertext_len;
	ERR_load_crypto_strings();

	/* Create and initialise the context */
	if (!(ctx = EVP_CIPHER_CTX_new()))
		printf("Context Initialization Error");

	/* Initialise the encryption operation.*/
	if (!EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
		printf("Encryption Initialization Error");

	/* Provide the message to be encrypted, and obtain the encrypted output.
	 * EVP_EncryptUpdate can be called multiple times if necessary
	 */
	if (!EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintextLen))
		printf("Encryption Operation Error");
	ciphertext_len = len;

	/* Finalise the encryption. Further ciphertext bytes may be written at
	 * this stage.
	 */
	if (!EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
		printf("Encryption Finalization Error");;
	ciphertext_len += len;

	/* Clean up */
	EVP_CIPHER_CTX_free(ctx);

	return ciphertext_len;
}

void flipFirstBit(char *text) {
  int number = text[0];
  number ^= 1 << 0;
  text[0] = number;
}

void createUdpMessage(unsigned char *iv, int ivLen, unsigned char *hmac, int hmacLen, unsigned char *ciphertext, int cipherTextLen, unsigned char* message) {
	mempcpy(mempcpy(mempcpy(message, iv, ivLen), hmac, hmacLen), ciphertext, cipherTextLen);
}

int main(int argc, char *argv[]) {
	struct sockaddr_in si_other;
	int slen, socket;
	char ciphertext[100];
	unsigned char hmac[100];
	unsigned int hmaclen;
	unsigned int cipherTextLen;
	char udpMessage[128];

	int ivLen = 32;
	unsigned char* iv;
	unsigned char* key;

	memset((char *) udpMessage, 0, sizeof(udpMessage));

	slen = sizeof(si_other);
	socket = createSocket();
	setupSocketInfo(&si_other, SRV_IP, PORT);
	
	key = argv[1];
	getRandom(ivLen, iv);

	cipherTextLen = encryptData(MSG, sizeof(MSG), key, iv, ciphertext);
	HMAC(EVP_sha256(), key, sizeof(key), ciphertext, cipherTextLen, hmac, &hmaclen);

	if (CORRUPT_MSG) {
      flipFirstBit(ciphertext);
    }

	createUdpMessage(iv, ivLen, hmac, hmaclen, ciphertext, cipherTextLen, udpMessage);

	printf("\nSending a packet.\n");

	if (sendto(socket, udpMessage, sizeof(udpMessage), 0, (struct sockaddr *)&si_other, slen) == -1) {
		perror("socket");
		printf("Sending failed.\n");
		exit(-1);
	}

	close(socket);
	return 0;
}