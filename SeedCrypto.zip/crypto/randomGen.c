#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#define LEN 16

unsigned char* getKey(int length) {
	unsigned char *key = (unsigned char *) malloc(sizeof(char)*length);
	FILE* random = fopen("/dev/random","r");
	fread(key, sizeof(char)*length, 1, random);
	fclose(random);
	return key;
}

int main(void){
	unsigned char *randomString;
	randomString = getKey(LEN);
	printf("%s\n", randomString);
}