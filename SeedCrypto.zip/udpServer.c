#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/types.h>
#include <sys/socket.h>

#define BUFLEN 512
#define PORT 9930

int createSocket(void) {
    int sock;
    if ((sock=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP))==-1){
        printf("Error at socket creation.\n");
        exit(-1);
    }
    return sock;
}

void bindToPort (int socket, int portNumber) {
    struct sockaddr_in hostSocketInfo;
    memset((char *) &hostSocketInfo, 0, sizeof(hostSocketInfo));

    hostSocketInfo.sin_family = AF_INET;
    hostSocketInfo.sin_port = htons(portNumber);
    hostSocketInfo.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(socket, (struct sockaddr *)&hostSocketInfo, sizeof(hostSocketInfo))==-1){
        printf("Error while binding to a port\n");
        exit(-1);
    }
}

int main(void) {
    struct sockaddr_in clientSocketInfo;
    int clientSockLength = sizeof(clientSocketInfo);
    char buf[BUFLEN];
    
    int socket = createSocket();
    bindToPort(socket, PORT);

    while (1) {
        if (recvfrom(socket, buf, BUFLEN, 0, (struct sockaddr *)&clientSocketInfo, &clientSockLength)==-1){
            printf("Error while recieving packets.\n");
            exit(-1);
        }
        printf("Received packet from %s:%d\nData: %s\n\n", inet_ntoa(clientSocketInfo.sin_addr), ntohs(clientSocketInfo.sin_port), buf);
    }

    close(socket);
    return 0;
}