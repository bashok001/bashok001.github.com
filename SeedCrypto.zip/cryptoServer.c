#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <openssl/evp.h>
#include <openssl/hmac.h>

#define PORT 9930

#define KEY "U0VFRFdvcmtzaG9wSW5KdW5lMTVBdFN5cmFjdXNlVW5pdmVyc2l0eQ"
#define IV "QXNob2tUYXVnaHRUaGlzQXRTVQ"

#define CORRUPT_MSG 0

int createSocket(void) {
    int sock;
    if ((sock=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP))==-1){
        printf("Error at socket creation.\n");
        exit(-1);
    }
    return sock;
}

void bindToPort (int socket, int portNumber) {
    struct sockaddr_in hostSocketInfo;
    memset((char *) &hostSocketInfo, 0, sizeof(hostSocketInfo));

    hostSocketInfo.sin_family = AF_INET;
    hostSocketInfo.sin_port = htons(portNumber);
    hostSocketInfo.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(socket, (struct sockaddr *)&hostSocketInfo, sizeof(hostSocketInfo))==-1){
        printf("Error while binding to a port\n");
        exit(-1);
    }
}

void decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
  unsigned char *iv, unsigned char *plaintext)
{
  EVP_CIPHER_CTX *ctx;
  int len;
  int plaintext_len;
  ERR_load_crypto_strings();
  /* Create and initialise the context */
  if(!(ctx = EVP_CIPHER_CTX_new())) {
    printf("decrypt new error\n");
    exit(-1);
  }

  /* Initialise the decryption operation. */
  if(!EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv)) {
    printf("decrypt init error\n");
    exit(-1);
  }

  /* Provide the message to be decrypted, and obtain the plaintext output.
   * EVP_DecryptUpdate can be called multiple times if necessary
   */
  if(!EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len)) {
    printf("decrypt update error\n");
    exit(-1);
  }
  plaintext_len = len;

  /* Finalise the decryption. Further plaintext bytes may be written at
   * this stage.
   */
  if(!EVP_DecryptFinal_ex(ctx, plaintext + len, &len)){
    ERR_print_errors_fp(stderr);
    printf("Decryption finalization error %s,%d\n",plaintext,len);
    printf("Verify the length of cipher text provided. If you're using UDP, read the exact length of cipherText\n");
  }
  plaintext_len += len;

  /* Clean up */
  EVP_CIPHER_CTX_free(ctx);
}

int verifyHMAC(char *hmac, char *calculatedHmac, int hmacLen){
    int i;
    for (i = 0; i < hmacLen; ++i) {
        if(hmac[i] != calculatedHmac[i])
            return 0;
    }
    return 1;
}

void flipFirstBit(char *text) {
    int number = text[0];
    number ^= 1 << 0;
    text[0] = number;
}

int main(void) {
    struct sockaddr_in clientSocketInfo;
    int clientSockLength, socket;
    char cipherText[64];
    char plainText[50];
    unsigned char hmac[100];
    unsigned int hmaclen;
    unsigned char calculatedHmac[100];
    unsigned int calculatedHmacLen;

    unsigned char tempHmac[100];
    unsigned int tempHmacLen;

    hmaclen = sizeof(hmac);
    calculatedHmacLen = sizeof(calculatedHmac);
    clientSockLength = sizeof(clientSocketInfo);
    
    socket = createSocket();
    
    bindToPort(socket, PORT);

    while (1) {
        if (recvfrom(socket, hmac, hmaclen, 0, (struct sockaddr *)&clientSocketInfo, &clientSockLength)==-1){
            printf("Error while recieving packets.\n");
            exit(-1);
        }

        if (recvfrom(socket, cipherText, sizeof(cipherText), 0, (struct sockaddr *)&clientSocketInfo, &clientSockLength)==-1){
            printf("Error while recieving packets.\n");
            exit(-1);
        }
        
        decrypt(cipherText, sizeof(cipherText), KEY, IV, plainText);
        
        if(CORRUPT_MSG) {
            flipFirstBit(plainText);
            printf("Text after flipping first bit is:\n%s\n", plainText);
        }

        HMAC(EVP_sha256(), KEY, sizeof(KEY), plainText, strlen(plainText), calculatedHmac, &calculatedHmacLen);
        
        if(!verifyHMAC(hmac, calculatedHmac, calculatedHmacLen)){
            printf("Hash mismatch. Terminating operation.\n\n");
            exit(-1);
        }
        else
            printf("Hash matched. Message Authenticated. \n\n");

        printf("Decrypted Data: %s\n", plainText);

    }

    close(socket);
    return 0;
}
